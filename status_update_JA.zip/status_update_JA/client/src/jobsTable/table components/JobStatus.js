import React from 'react';

const JobStatus = (props) => {
  return (
    <>
        { props.children }
    </>
  );
}

export default JobStatus;