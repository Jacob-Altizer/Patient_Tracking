import React from 'react';
import './ManageJobsForm.css';

const CreateJob = () => {
  return (
    <>
      
    </>
  );
};